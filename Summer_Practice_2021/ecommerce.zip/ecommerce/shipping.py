def calc_shpping():
    print("calc_shipping")