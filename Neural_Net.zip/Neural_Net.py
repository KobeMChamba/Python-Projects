from neural import *

# nn = NeuralNet(2, 5, 1)
#
# xorData = [([1.0,1.0], [0.0]), ([0.0,1.0], [1.0]), ([1.0,0.0], [1.0]), ([0.0, 0.0], [0.0])]
#
# nn.train(xorData,
#          iters = 10000,
#          print_interval=100)


# nn = NeuralNet(2, 5, 1)
#
# xorData = [([1.0,1.0], [0.0]), ([0.0,1.0], [1.0]), ([1.0,0.0], [1.0]), ([0.0, 0.0], [0.0])]
#
# nn.train(xorData,
#          iters = 10000,
#          print_interval=100)
#
# nn = NeuralNet(2, 1, 1)
#
# xorData = [([1.0,1.0], [0.0]), ([0.0,1.0], [1.0]), ([1.0,0.0], [1.0]), ([0.0, 0.0], [0.0])]
#
# nn.train(xorData,
#          iters = 10000,
#          print_interval=100)


# 1. The weights converge after 1400 iterations
# the final error is 0.0004097621637155905 after 10,000 iterations
# The convergence rate when there is one hidden node is: 0.34321398513316176
# The convergence rate when there is two hidden nodes is: 0.0004558135164247039

# nn = NeuralNet(2, 2, 1)
#
# xorData = [([1.0,1.0], [0.0]), ([0.0,1.0], [1.0]), ([1.0,0.0], [1.0]), ([0.0, 0.0], [0.0])]
#
# nn.train(xorData,
#          iters = 10000,
#          print_interval=100)



# nn = NeuralNet(2, 8, 1)
#
# xorData = [([1.0,1.0], [0.0]), ([0.0,1.0], [1.0]), ([1.0,0.0], [1.0]), ([0.0, 0.0], [0.0])]
#
# nn.train(xorData,
#          iters = 10000,
#          print_interval=100)
#
# 2. The convergence rate was higher for the 8 hide node network.
# The error was below 0.001 after 3500 iterations compared to 3700 for the five hidden nodes system and 8900
# for the two hidden nodes system
# It was a better approximation of the XOR function as well but by very little compared to the five hidden nodes
# system.
# 3. The convergence rate for a one hidden node network never falls below 0.34
#
# polnn = NeuralNet(5, 1, 1)
#
# voterData1 = [([0.9, 0.6, 0.8, 0.3, 0.1], [1.0]), ([0.8, 0.8, 0.4, 0.6, 0.4], [1.0]),
#               ([0.7, 0.2, 0.4, 0.6, 0.3], [1.0]), ([0.5, 0.5, 0.8, 0.4, 0.8], [0.0]),
#               ([0.3, 0.1, 0.6, 0.8, 0.8], [0.0]), ([0.6, 0.3, 0.4, 0.3, 0.6], [0.0])]
#
# polnn.train(voterData1,
#             iters=10000,
#             print_interval=2000)
#
# print("Ih weights")
# for item in polnn.get_ih_weights():
#     print(item)
# print("Ho weights")
# for item in polnn.get_ho_weights():
#     print(item)
#
# for triple in polnn.test_with_expected(voterData1):
#     print(triple)
#
#
# polnn = NeuralNet(5, 1, 1)
#
# voterData2 = [([1.0, 1.0, 1.0, 0.1, 0.1], [1.0]), ([0.5, 0.2, 0.1, 0.7, 0.7], [0.0]),
#               ([0.8, 0.3, 0.3, 0.3, 0.8], [0.0]), ([0.8, 0.3, 0.3, 0.8, 0.3], [1.0]),
#               ([0.9, 0.8, 0.8, 0.3, 0.6], [0.0])]
#
# polnn.train(voterData2,
#             iters=10000,
#             print_interval=2000)
#
# for item in polnn.get_ih_weights():
#     print(item)
# print("")
# for item in polnn.get_ho_weights():
#     print(item)
#
# for triple in polnn.test_with_expected(voterData2):
#     print(triple)


# 4. For the first data set, a high budget score and environment score is correlated to a republican score
# On the other hand Social security deeply correlates with a democratic score

# For the second data set budget and environment correlate with with republican score
# Social security deeply correlates with a democratic score



#ALL ANSWERS
# 1. The weights converge after 1400 iterations
# the final error is 0.0004097621637155905 after 10,000 iterations
# The convergence rate when there is one hidden node is: 0.34321398513316176
# The convergence rate when there is two hidden nodes is: 0.0004558135164247039

# 2. The convergence rate was higher for the 8 hide node network.
# The error was below 0.001 after 3500 iterations compared to 3700 for the five hidden nodes system and 8900
# for the two hidden nodes system
# It was a better approximation of the XOR function as well but by very little compared to the five hidden nodes
# system.

# 3. The convergence rate for a one hidden node network never falls below 0.34

# 4. For the first data set, a high budget score and environment score is correlated to a republican score
# On the other hand Social security deeply correlates with a democratic score

# For the second data set budget and environment correlate with with republican score
# Social security deeply correlates with a democratic score
